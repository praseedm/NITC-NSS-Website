var t=1;

var option_list=['Home','About Us','Collaborations','Get involved'];

function filloptions(t,call){
  for(var i=0;i<t;i++){
      var element=$("<span id=\"opt"+i+"\" class=\"option_unselected\">"+option_list[i]+"</span>");
      $("#option_bar").append(element);
          var element=$("<span id=\"opt"+i+"\" class=\"option_unselected\">"+option_list[i]+"</span>");
      $("#top-bar").append(element);
  }
  call();
}

function menuhandler(){
  $(".option_unselected").mouseover(function(){
    console.log(this.id);
      $(this).toggleClass("option_selected option_unselected");

  });
  $(".option_unselected").mouseleave(function(){
    $(this).toggleClass("option_selected option_unselected");
  });
}
function scrollhandler(y){
  if(y>250){
    $("#top-bar").fadeIn();
  }
  else{
    $("#top-bar").fadeOut();
  }
}
$(document).ready(function(){
  filloptions(10,function(){
    menuhandler();
  });
  $(window).scroll(function(){
    scrollhandler($(window).scrollTop());
  })
});
